const uploadHandler=(req,res,oracledb,dbAttr)=>{
  let sampleFile;
  let uploadPath;
  const hub=req.params.HUB;
  console.log(hub)
    if (Object.keys(req.files).length == 0) {
      res.status(400).send('No files were uploaded.');
      return;
    }
      console.log('req.files >>>', req.files); 
      sampleFile = req.files.sampleFile;
      const fname=sampleFile.name.split('.')[0];
      const ftype=sampleFile.name.split('.')[1];
      const time=new Date().getTime().toString();
      const finalFname=fname+time.concat('.',ftype);
      uploadPath = './public/' + finalFname;
      sampleFile.mv(uploadPath, function(err) {
      if (err) {
        return res.status(500).send(err);
      }
      var content=`http://localhost:3001/${finalFname}`
         
      console.log(content)
          //Database Connection
   oracledb.getConnection(
  dbAttr
,
function(err, connection) {
  if (err) {
    console.error(err.message);
    return;
  }
  connection.execute(`INSERT INTO signage values(:HUB,:CONTENT,:IMG_ID,:FILE_NAME_ID,:FILE_NAME)
      `,[hub,content,null,(sampleFile.name+new Date()),finalFname],
      {   autoCommit:true,
          outFormat:oracledb.OBJECT},
       function(err, result) {
      if (err) {
        console.error(err.message);
        doRelease(connection);
        return;
      }
      console.log(content)
      console.log(result.rowAffected);
      res.redirect('http://localhost:3000');
      doRelease(connection);
    });
});
const doRelease=(connection)=> {
connection.close(
  function(err) {
    if (err)
      console.error(err.message);
  });
}
  });
}
module.exports={
  uploadHandler:uploadHandler
}