const imageHandler=(req,res,oracledb,dbAttr)=>{
		const hub=req.params.HUB;
     	console.log(hub)
  oracledb.getConnection(dbAttr,function(err, connection) {
    if (err) {
      console.error(err.message);
      return;
    }
    connection.execute(`SELECT IMG_ID,CONTENT FROM signage 
    	WHERE HUB=:HUB
    	`,[hub],
    	{outFormat:oracledb.OBJECT},
         function(err, result) {
        if (err) {
          console.error(err.message);
          doRelease(connection);
          return;
        }
        console.log(result);
        if(result.rows.length>0){
        res.json(result.rows);
    }
    else{
    	res.json([])
    }

        doRelease(connection);
      });
  });

function doRelease(connection) {
  connection.close(
    function(err) {
      if (err)
        console.error(err.message);
    });
}
}


module.exports={
	imageHandler:imageHandler
} 