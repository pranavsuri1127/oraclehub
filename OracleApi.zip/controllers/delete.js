const fs=require('fs');
const deleteHandler=(req,res,oracledb,dbAttr)=>{
        const img_id=req.params.IMG_ID;

        var FILE_NAME;
     oracledb.getConnection(dbAttr,function(err, connection)
     {
       if (err) {
         console.error(err.message);
         return;
       }
       connection.execute(`Delete from signage WHERE IMG_ID=:IMG_ID returning FILE_NAME into :FILE_NAME`,
       {
           IMG_ID:img_id,
           FILE_NAME:  { type: oracledb.STRING, dir: oracledb.BIND_OUT }
       },
       {    autoCommit:true,
           outFormat:oracledb.OBJECT,
           
       },
        (err, result) =>{
       if (err) {
         console.error(err.message);
         doRelease(connection);
         return;
       }
       else if(result.rowsAffected<1){
           console.error('no rows');
         doRelease(connection);

         return;
       }
       const delFile=result.outBinds.FILE_NAME[0]
       console.log(result.outBinds.FILE_NAME[0]);

          fs.unlinkSync(`./public/${delFile}`,(err)=>{
              if(err){
                  console.error(err)
              }
              console.log('File Deleted from server')
          });
       res.json('deleted successfully');
       doRelease(connection);
     });
 });
            
            const doRelease=(connection)=> {
              connection.close(
                function(err) {
                  if (err)
                    console.error(err.message);
                });
            }

}


module.exports={
    deleteHandler:deleteHandler
}