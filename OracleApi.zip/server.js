const express=require('express');
const fileUpload = require('express-fileupload');
var oracledb = require('oracledb');
const getImages=require('./controllers/image');
const app=express();
const bodyParser=require('body-parser');
const upload=require('./controllers/upload');
const deleteImg=require('./controllers/delete');
const cors=require('cors');
app.use(fileUpload());
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public'));

const dbAttr={
    user          : "seaas",
    password      : "seaas",
    connectString : "solutionengineering-devops.us.oracle.com/sepdbdev.us.oracle.com"
  }


app.get('/images/:HUB',(req,res)=>{getImages.imageHandler(req,res,oracledb,dbAttr)});


app.post('/upload/:HUB',(req, res)=>{upload.uploadHandler(req,res,oracledb,dbAttr)});


app.delete('/delete/:IMG_ID',(req,res)=>{deleteImg.deleteHandler(req,res,oracledb,dbAttr)});

var server=app.listen(3001,()=>
{
	console.log("Got You");
	
	console.log(server.address().address)
})
