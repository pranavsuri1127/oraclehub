var express = require("express");
var app = express();
app.listen(3010, () => {
 console.log("Server running on port 3010");
});

var images = {
				items:[{
                    pic:"https://images.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
					id: 1
				},
				{
					pic: "https://wallpaperbrowse.com/media/images/3848765-wallpaper-images-download.jpg",
					id: 2
				},
				{
					pic: "https://wallpaper-gallery.net/images/images/images-2.jpg",
					id: 3
				},
				{
					pic: "https://www.w3schools.com/w3css/img_lights.jpg",
					id: 4
                },
                {
					pic: "https://www.oxforduniversityimages.com/images/rotate/Image_Spring_17_4.gif",
					id: 5
				}]
            }
            
app.get("/img", (req, res, next) => {
    res.json(images)   
});

app.delete('/img/:id', function(req, res) {
    let img_id = req.params.id;
    var destArr=[];
    var srcArr= images.items
    for(i in srcArr){ 
      if(srcArr[i].id!= img_id) 
            destArr[i]=srcArr[i];
      }
	srcArr=destArr; 
	console.log(res);
});