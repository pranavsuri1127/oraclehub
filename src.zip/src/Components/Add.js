import React from 'react';

const Add=()=>{
	return(
        <div className="tooltip">
            <span className="tooltiptext">Add Images</span>
            <div className="add">
                <div id="parent">
                    <div id="div1"></div>
                    <div id="div2"></div>
                </div>
            </div>
        </div>
	)
}

export default Add;